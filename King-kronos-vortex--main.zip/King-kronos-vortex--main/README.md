# King-kronos-vortex-
King kronos vortex se yon jèn atis ki pote bon jan Gou lan mizik ayisyen an AK anpil tandans tankou rap trap afro gospel amapianoak anpil lòt ankò 
